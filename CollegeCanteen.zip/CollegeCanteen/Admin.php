<?php
    // check if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // retrieve input values
        $username = $_POST["uname"];
        $password = $_POST["psw"];
        
        // validate username and password
        if ($username === "ADMIN" && $password === "ADMIN123") {
            // credentials are correct, redirect to homepage
            header("Location: infoadmin.php");
            exit();
        } else {
            // credentials are incorrect, show error message
            $error_msg = "Invalid username or password!";
        }
    }
?>

<!-- HTML code with embedded PHP code -->
<style>
	body {
		background-color: #fefbd8;
	}
	h1 {
		background-color: #333;
		color: white;
	}
</style>
<div id="my_form">
	<center>
		<img src="https://www.collegesignal.com/images/colleges/cz_5ec75719b74e5202245/logo/M%20Kumarasamy%20College%20of%20Engineering%20logo-m4306-original.jpg">
		<br>
		<br>
		<h2>Kumarasamy College of Engineering</h2>
		<h3>CANTEEN ADMIN LOGIN</h3>
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
			<label for="uname"><b>Username</b></label>
			<input type="text" placeholder="Enter Username" name="uname" required>
			<br>
			<br>
			<label for="psw"><b>Password</b></label>
			<input type="password" placeholder="Enter Password" name="psw" required>
			<br>
			<br>
			<button type="submit">Login</button>
		</form>
		<?php if(isset($error_msg)) echo "<p style='color:red;'>$error_msg</p>"; ?>
	</center>
</div>
