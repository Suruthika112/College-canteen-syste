<style>
    body {
        background-color: #fefbd8;
    }
    h1 {
        background-color: #333;
        color: white;
    }
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

th {
  background-color: #333;
  color: white;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

td {
  border-bottom: 1px solid #ddd;
}

</style>

<div id="my_form">
    <center>
        <br>
        <br>
        <h2>FOOD  ORDER DETAILS </h2>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="date"><b>Date</b></label>
            <input type="date" name="date" required>
            <br>
            <br>
            <h4>ORDER DETAILS ON THE GIVEN DATE</h4> 
            
            
            <br>
            <button type="submit">Submit</button>
            <br>
        </form>

        <?php 
include "db_conx.php";

if (mysqli_connect_errno()) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // retrieve input values
    $date = $_POST["date"];
  
  
    
    // select all rows from leave_requests table
    $sql = "SELECT * FROM food1_request WHERE order_date = '$date' ORDER BY food_id";
    $result = mysqli_query($conn, $sql);

    // output data as HTML table
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<tr><th>User id</th><th>Full name</th><th>Order date</th><th>Food id</th></tr>";
        while($row = mysqli_fetch_assoc($result)) {
		
            echo "<tr>";
            echo "<td>".$row["reg_number"]."</td>";
            echo "<td>".$row["full_name"]."</td>";
            echo "<td>".$row["order_date"]."</td>";
            echo "<td>".$row["food_id"]."</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No one has ordered yet";
    }
}

// close database connection
mysqli_close($conn);
?>
        

        <?php if(isset($error_msg)) { echo "<p style='color:red;'>$error_msg</p>"; } ?>
        <form action="front.php" method="POST">
            <h4>Please logout if your search is done</h4>
            <button type="submit">Logout</button>
        </form>

    </center>
</div>
