<!DOCTYPE html>
<html>
<head>
  <title>Food oredr Form</title>
</head>
<body>

<?php
// handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  

  // check connection
  // get form data
  $reg_number = $_POST["reg_number"];
  $full_name = $_POST["full_name"];
  $order_date = $_POST["order_date"];
  $food_id = $_POST["food_id"];
include "db_conx.php";

  // prepare SQL statement
  $sql = "INSERT INTO food1_request (reg_number, full_name, order_date, food_id) 
          VALUES ('$reg_number', '$full_name', '$order_date', '$food_id')";

  // execute SQL statement
  if (mysqli_query($conn, $sql)) {
      header("Location: front.php");
            exit();
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  // close database connection
  mysqli_close($conn);
}
?>
<style>
	body {
		background-color: #fefbd8;
	}
	h1 {
		background-color: #333;
		color: white;
	}
</style>
<center>

<h1>FOOD ORDER Form</h1>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <p>
    <label>User id</label>
 
	<input type="text" placeholder="Reg no/staff id/driver id" name="reg_number" required>
  </p>
  <p>
    <label>Full name</label>
    <input type="text" placeholder="Enter name" name="full_name" required>
  </p>

  <p>
    <label for="orderDate">Date of order</label>
    <input type="date" id="orderDate" name="order_date" required>
  </p>
  <p>
    <label>Order id</label>
    <input type="text" placeholder="Enter order id" name="food_id" required>
  </p>
  <br>
  <button type="submit">Submit</button>
</form>
</center>
</body>
</html>
