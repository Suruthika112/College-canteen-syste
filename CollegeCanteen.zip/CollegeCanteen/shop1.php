<html>
    <head>
        <link rel = "icon" href = "https://i.pinimg.com/originals/a9/c5/2e/a9c52e28c162e8fb6194705288f3e19e.jpg" type = "image/m-icon">
        <title>Foodie-Online  Ordering</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">       
        <link href="StyleSheet.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Charmonman|Lobster|Pacifico|Poppins|Raleway|Ubuntu" rel="stylesheet">   
   <form action="order.php" method="POST">     
    </head>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script> 
<h1><center>HOTEL MAYURA FOOD DETAILS</center></h1>   
 <!--Restaurant Block 1-->
                    <div class="listing-grid">
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://feenix.co.in/wp-content/uploads/2022/07/c2362bc8-590d-430c-a75f-660be4a26d2c.jpg" >
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Chicken Fried Rice</h3>
                                    <div class="info">
                                    </div>
                                </div>
                                </div>
                                <div class="info-rating">
                                        <ul>
                                            <li class="Rating-Star">
                                                <span><i class="fas fa-star"></i></span>
                                                <span>4.5</span>
                                            </li>
                                            <li>•</li>
                                            <li>35 MINS</li>
							   <li>Order id: 1</li>
                                            <li>•</li>
                                            <li>Rs.120</li>
                                        </ul>
                                </div>
                                <div class="lower-text">
                                    <div class="SmallText">
                                    <p>Get renfund within 20 min from order </p>                                
                                </div>
                            </div>
                        </div>
            
            
            
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://i.ytimg.com/vi/GxerXnzENc0/maxresdefault.jpg" >
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Egg Noodles</h3>
                                    <div class="info">                              
                                    </div>
                                </div>
                            </div>  
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star "></i></span>
                                        <span>4.7</span>
                                    </li>
                                    <li>•</li>
                                    <li>35 MINS</li>
						<li>Order id: 2</li>
                                    <li>•</li>
                                    <li>Rs.100</li>
                                </ul>
                        </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>Get renfund within 20 min from order </p>                                
                        </div>
                    </div>
                </div>
                            <div class="listing-grid-elements">
                                <div class="image1">
                                    <img src="https://i.pinimg.com/736x/09/f5/96/09f596e45c905793522e37228f9b57ea.jpg">
                                </div>
                                <div class="text">
                                    <div class="text-title">
                                        <h3>Veg Noodles</h3>
                                    </div>  
                                </div>
                                    <div class="info-rating">
                                        <ul>
                                            <li class="Rating-Star">
                                                <span><i class="fas fa-star"></i></span>
                                                <span>4.0</span>
                                            </li>
                                            <li>•</li>
                                            <li>25 MINS</li>
							  <li>Order id: 3</li>
                                            <li>•</li>
                                            <li>Rs.60</li>
                                        </ul>
                                    </div>
                                <div class="lower-text">
                                    <div class="SmallText">
                                    <p>Get renfund within 30 min from order </p>                                
                                </div>
                            </div>
                        </div>
                        
            
                            
            
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://i.ytimg.com/vi/MhzBUy-JOCE/maxresdefault.jpg">
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Chicken Noodles</h3>
                                </div>  
                            </div>
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.2</span>
                                    </li>
                                    <li>•</li>
                                    <li>45 MINS</li>
						<li>Order id: 4</li>
                                    <li>•</li>
                                    <li>Rs.130</li>
                                </ul>
                            </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>Get renfund within 20 min from order </p>                                
                        </div>
                    </div>
                </div>
               </div>  

            <!--Restaurant Block 2-->

            <div class="listing-grid">
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://redhousespice.com/wp-content/uploads/2021/10/Chinese-egg-fried-rice-in-a-bowl-scaled.jpg" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Egg Fried Rice</h3>
                        </div>
                        </div>
                        <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.1</span>
                                    </li>
                                    <li>•</li>
                                    <li>30 Mins</li>
						<li>Order id: 5</li>
                                    <li>•</li>
                                    <li>Rs.100</li>
                                </ul>
                        </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>Get renfund within 20 min from order </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://recipesofhome.com/wp-content/uploads/2020/06/veg-fried-rice-recipe.jpg" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Veg Fried Rice</h3>
                        </div>
                    </div>  
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.5</span>
                            </li>
                            <li>•</li>
                            <li>20 Mins</li>
					<li>Order id: 6</li>
                            <li>•</li>
                            <li>Rs.60</li>
                        </ul>
                </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>Get renfund within 10 min from order   </p>                                
                </div>
            </div>
        </div>
    
    
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://img-global.cpcdn.com/recipes/d13eda0a4854a298/1200x630cq70/photo.jpg">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Chicken Kothuporata</h3>
                            </div>  
                        </div>
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.0</span>
                                    </li>
                                    <li>•</li>
                                    <li>50 Mins</li>
						<li>Order id: 7</li>
                                    <li>•</li>
                                    <li>Rs.100</li>
                                </ul>
                            </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>Get renfund within 30 min from order  </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://www.sailusfood.com/wp-content/uploads/2013/12/kothu-parotta.jpg">
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Egg Kothu Parota</h3>
                        </div>  
                    </div>
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.1</span>
                            </li>
                            <li>•</li>
                            <li>45 Mins</li>
					<li>Order id: 8</li>
                            <li>•</li>
                            <li>Rs.90</li>
                        </ul>
                    </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>Get renfund within 30 min from order  </p>                                
                </div>
            </div>
        </div>
       </div>  

                <!--Restaurant Block 3 -->
                <div class="listing-grid">
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://cdn.shopify.com/s/files/1/0555/8947/0401/products/29222-0001_1200x.jpg?v=1665140048" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Rose Milk</h3>
                            </div>
                            </div>
                            <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>5.0</span>
                                        </li>
                                        <li>•</li>
                                        <li>kavins</li>
							<li>Order id: 9</li>
                                        <li>•</li>
                                        <li>Rs.35</li>
                                    </ul>
                            </div>
                            <div class="lower-text">
                                <div class="SmallText">             
			<p>No refund </p>                      
                            </div>
                        </div>
                    </div>
        
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://cdn.igp.com/f_auto,q_auto,t_pnopt6prodlp/products/p-classic-black-forest-cake-half-kg--108742-m.jpg" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Black Forest cake</h3>
                            </div>
                        </div>  
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star  avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.0</span>
                                </li>
                                <li>•</li>
                                <li>instant</li>
						<li>Order id: 10</li>
                                <li>•</li>
                                <li>Rs.50 For a Piece</li>
                            </ul>
                    </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund </p>                                
                    </div>
                </div>
            </div>
        
        
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://geekrobocook.com/wp-content/uploads/2021/03/White-Forest-Cake.jpg">
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>White forest Cake</h3>
                                </div>  
                            </div>
                                <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>4.3</span>
                                        </li>
                                        <li>•</li>
                                        <li>43 Mins</li>
							<li>Order id: 11</li>
                                        <li>•</li>
                                        <li>Rs.40 For a  Piece</li>
                                    </ul>
                                </div>
                            <div class="lower-text">
                                <div class="SmallText">
		<p>No Refund</p>
		</div>
                        </div>
                    </div>
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/c/cb/Samosachutney.jpg">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Samosa</h3>
                            </div>  
                        </div>
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.9</span>
                                </li>
                                <li>•</li>
                                <li>Instant</li>
						<li>Order id: 12</li>
                                <li>•</li>
                                <li>Rs.15 For Two</li>
                            </ul>
                        </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund </p>                                
                    </div>
                </div>
            </div>
           </div> 
        

           <!--Restaurant Block  4-->
           <div class="listing-grid">
            <div class="listing-grid-elements">
                <div class="image1">
                    <img src="https://lh4.ggpht.com/-ORog6b7Y_ec/TfmeMFMGa3I/AAAAAAAAGTI/WZhfoCwR1Lo/DSC_1241_thumb.jpg?imgmax=800" >
                </div>
                <div class="text">
                    <div class="text-title">
                        <h3>Chicken Puffs</h3>
                    </div>
                    </div>
                    <div class="info-rating">
                            <ul>
                                <li class="Rating-Star">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>4.0</span>
                                </li>
                                <li>•</li>
                                <li>Instant</li>
						<li>Order id: 13</li>
                                <li>•</li>
                                <li>Rs.35 </li>
                            </ul>
                    </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund</p>                                
                    </div>
                </div>
            </div>



            <div class="listing-grid-elements">
                <div class="image1">
                    <img src="https://1.bp.blogspot.com/-snMCL1a55cc/YHgoKUJOZgI/AAAAAAAASFA/HYfsSXCEEgES4sQU_Ydnha1Vr71bVNIdgCLcBGAsYHQ/s2000/IMG_20210404_223034_compress1.jpg" >
                </div>
                <div class="text">
                    <div class="text-title">
                        <h3>Chicken Roll</h3>
                    </div>
                </div>  
                <div class="info-rating">
                    <ul>
                        <li class="Rating-Star">
                            <span><i class="fas fa-star"></i></span>
                            <span>4.1</span>
                        </li>
                        <li>•</li>
                        <li>Instant</li>
				<li>Order id: 14</li>
                        <li>•</li>
                        <li>Rs.30</li>
                    </ul>
            </div>
            <div class="lower-text">
                <div class="SmallText">
                <p>No refund</p>                                
            </div>
        </div>
    </div>

                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://www.indianhealthyrecipes.com/wp-content/uploads/2022/03/chicken-65-restaurant-style-500x375.jpg">
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Chicken 65</h3>
                        </div>  
                    </div>
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>4.9</span>
                                </li>
                                <li>•</li>
                                <li>60 Mins</li>
					<li>Order id: 15</li>
                                <li>•</li>
                                <li>Rs.200 </li>
                            </ul>
                        </div>
                    <div class="lower-text">
                        <div class="SmallText">  
	<p>Refund With in 20 min from order </p>                             
                    </div>
                </div>
            </div>

            <div class="listing-grid-elements">
                <div class="image1">
                    <img src="https://spicecravings.com/wp-content/uploads/2020/12/Roti-Featured-1-500x375.jpg">
                </div>
                <div class="text">
                    <div class="text-title">
                        <h3>Chappati</h3>
                    </div>  
                </div>
                <div class="info-rating">
                    <ul>
                        <li class="Rating-Star">
                            <span><i class="fas fa-star"></i></span>
                            <span>3.5</span>
                        </li>
                        <li>•</li>
                        <li>25 Mins</li>
				<li>Order id: 16</li>
                        <li>•</li>
                        <li>Rs.40 For Two</li>
                    </ul>
                </div>
            <div class="lower-text">
                <div class="SmallText">
                <p>Get Refund within 10 min from order</p>                                
            </div>
        </div>
    </div>
   </div>
<br>
<br>

            
            <center><a href="order.php">Order</a>
        </form>
   <br>
<br>

   