<html>
    <head>
        <link rel = "icon" href = "https://i.pinimg.com/originals/a9/c5/2e/a9c52e28c162e8fb6194705288f3e19e.jpg" type = "image/m-icon">
        <title>Foodie-Online  Ordering</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">       
        <link href="StyleSheet.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Charmonman|Lobster|Pacifico|Poppins|Raleway|Ubuntu" rel="stylesheet">        
    </head>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script> 
<h1><center>CAFE FOOD DETAILS</center></h1>   
 <!--Restaurant Block 1-->
                    <div class="listing-grid">
                       
            
            
            
                      
                        
             <form action="order.php" method="POST"> 
                         
                       

            <!--Restaurant Block 2-->

            <div class="listing-grid">
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://funmoneymom.com/wp-content/uploads/2021/03/Chocolate-Milkshake-square-735x735.jpg" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Chocolate Milkshake</h3>
                        </div>
                        </div>
                        <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.2</span>
                                    </li>
                                    <li>•</li>
                                    <li>15 Mins</li>
						 <li>food id:17</li>
                                    <li>•</li>
                                    <li>Rs.60</li>
                                </ul>
                        </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No refund </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="http://thepepper.in/wp-content/uploads/2019/02/Butterscotch-Milkshake.jpg" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Butterscotch Milkshake</h3>
                        </div>
                    </div>  
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.2</span>
                            </li>
                            <li>•</li>
                            <li>20 Mins</li>
					<li>food id:18</li>
                            <li>•</li>
                            <li>Rs.60</li>
                        </ul>
                </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>No refund </p>                                
                </div>
            </div>
        </div>
    
    
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://2.bp.blogspot.com/-Q9lfQWDxdbI/XK1xXx0icpI/AAAAAAAAHYs/imzTLZRp-_QVtIA9vRvzm9hBtFlR-O23wCLcBGAs/s1600/IMG_0792.jpg">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Grape Milkshake</h3>
                            </div>  
                        </div>
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.0</span>
                                    </li>
                                    <li>•</li>
                                    <li>20 Mins</li>
						<li>food id:19</li>
                                    <li>•</li>
                                    <li>Rs.60</li>
                                </ul>
                            </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No refund  </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://asmallbite.com/wp-content/uploads/2019/05/Grilled-Paneer-Sandwich.jpg">
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Paneer Sandwich</h3>
                        </div>  
                    </div>
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.8</span>
                            </li>
                            <li>•</li>
                            <li>30 Mins</li>
				<li>food id:20</li>
                            <li>•</li>
                            <li>Rs.45</li>
                        </ul>
                    </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>Get renfund within 5 min from order  </p>                                
                </div>
            </div>
        </div>
       </div>  

                <!--Restaurant Block 3 -->
                <div class="listing-grid">
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://www.pepperbowl.com/wp-content/uploads/2019/09/how-to-make-rose-milk-syrup.jpg" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Rose Milk</h3>
                            </div>
                            </div>
                            <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>5.0</span>
                                        </li>
                                        <li>•</li>
                                        <li>15 Mins</li>
							<li>food id:21</li>
                                        <li>•</li>
                                        <li>Rs.35</li>
                                    </ul>
                            </div>
                            <div class="lower-text">
                                <div class="SmallText">             
			<p>No refund </p>                      
                            </div>
                        </div>
                    </div>
        
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://www.indianhealthyrecipes.com/wp-content/uploads/2021/06/strawberry-milkshake-recipe.jpg" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Strawberry Milkshake</h3>
                            </div>
                        </div>  
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star  avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.5</span>
                                </li>
                                <li>•</li>
                                <li>instant</li>
					<li>food id:22</li>
                                <li>•</li>
                                <li>Rs.50 For a Piece</li>
                            </ul>
                    </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund </p>                                
                    </div>
                </div>
            </div>
        
        
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://www.sharmispassions.com/wp-content/uploads/2016/04/VanillaMilkshake4.jpg">
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Vanilla Milkshake</h3>
                                </div>  
                            </div>
                                <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>4.7</span>
                                        </li>
                                        <li>•</li>
                                        <li>10 Mins</li>
							<li>food id:23</li>
                                        <li>•</li>
                                        <li>Rs.10</li>
                                    </ul>
                                </div>
                            <div class="lower-text">
                                <div class="SmallText">
		<p>No Refund</p>
		</div>
                        </div>
                    </div>
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://www.cafechococraze.com/wp-content/uploads/2016/06/black-currant-thick-shake.jpg">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Blackcurrent Milkshake</h3>
                            </div>  
                        </div>
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.0</span>
                                </li>
                                <li>•</li>
                                <li>Instant</li>
					<li>food id:24</li>
                                <li>•</li>
                                <li>Rs.15 </li>
                            </ul>
                        </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund </p>                                
                    </div>
                </div>
            </div>
           </div>
 <center><a href="order.php">Order</a>
        </form>