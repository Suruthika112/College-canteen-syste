<html>
    <head>
        <link rel = "icon" href = "https://i.pinimg.com/originals/a9/c5/2e/a9c52e28c162e8fb6194705288f3e19e.jpg" type = "image/m-icon">
        <title>Foodie-Online  Ordering</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">       
        <link href="StyleSheet.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Charmonman|Lobster|Pacifico|Poppins|Raleway|Ubuntu" rel="stylesheet">        
    </head>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script> 
 <form action="order.php" method="POST"> 
<h1><center>BEST CANTEEN FOOD DETAILS</center></h1>   
 <!--Restaurant Block 1-->
                    <div class="listing-grid">
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://feenix.co.in/wp-content/uploads/2022/07/c2362bc8-590d-430c-a75f-660be4a26d2c.jpg" >
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Chicken Fried Rice</h3>
                                    <div class="info">
                                    </div>
                                </div>
                                </div>
                                <div class="info-rating">
                                        <ul>
                                            <li class="Rating-Star">
                                                <span><i class="fas fa-star"></i></span>
                                                <span>4.5</span>
                                            </li>
                                            <li>•</li>
                                            <li>35 MINS</li>
							<li>food id:25</li>
                                            <li>•</li>
                                            <li>Rs.120</li>
                                        </ul>
                                </div>
                                <div class="lower-text">
                                    <div class="SmallText">
                                    <p>Get renfund within 20 min from order </p>                                
                                </div>
                            </div>
                        </div>
            
            
            
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://i.ytimg.com/vi/GxerXnzENc0/maxresdefault.jpg" >
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Egg Noodles</h3>
                                    <div class="info">                              
                                    </div>
                                </div>
                            </div>  
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star "></i></span>
                                        <span>4.7</span>
                                    </li>
                                    <li>•</li>
                                    <li>35 MINS</li>
						<li>food id:26</li>
                                    <li>•</li>
                                    <li>Rs.100</li>
                                </ul>
                        </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>Get renfund within 20 min from order </p>                                
                        </div>
                    </div>
                </div>
                            <div class="listing-grid-elements">
                                <div class="image1">
                                    <img src="https://i.pinimg.com/736x/09/f5/96/09f596e45c905793522e37228f9b57ea.jpg">
                                </div>
                                <div class="text">
                                    <div class="text-title">
                                        <h3>Veg Noodles</h3>
                                    </div>  
                                </div>
                                    <div class="info-rating">
                                        <ul>
                                            <li class="Rating-Star">
                                                <span><i class="fas fa-star"></i></span>
                                                <span>4.0</span>
                                            </li>
                                            <li>•</li>
                                            <li>25 MINS</li>
							<li>food id:27</li>
                                            <li>•</li>
                                            <li>Rs.60</li>
                                        </ul>
                                    </div>
                                <div class="lower-text">
                                    <div class="SmallText">
                                    <p>Get renfund within 30 min from order </p>                                
                                </div>
                            </div>
                        </div>
                        
            
                            
            
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://i.ytimg.com/vi/MhzBUy-JOCE/maxresdefault.jpg">
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Chicken Noodles</h3>
                                </div>  
                            </div>
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.2</span>
                                    </li>
                                    <li>•</li>
                                    <li>45 MINS</li>
						<li>food id:28</li>
                                    <li>•</li>
                                    <li>Rs.130</li>
                                </ul>
                            </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>Get renfund within 20 min from order </p>                                
                        </div>
                    </div>
                </div>
               </div>  

            <!--Restaurant Block 2-->

            <div class="listing-grid">
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://funmoneymom.com/wp-content/uploads/2021/03/Chocolate-Milkshake-square-735x735.jpg" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Chocolate Milkshake</h3>
                        </div>
                        </div>
                        <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.5</span>
                                    </li>
                                    <li>•</li>
                                    <li>15 Mins</li>
						<li>food id:29</li>
                                    <li>•</li>
                                    <li>Rs.60</li>
                                </ul>
                        </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No refund </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="http://thepepper.in/wp-content/uploads/2019/02/Butterscotch-Milkshake.jpg" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Butterscotch Milkshake</h3>
                        </div>
                    </div>  
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.7</span>
                            </li>
                            <li>•</li>
                            <li>20 Mins</li>
					<li>food id:30</li>
                            <li>•</li>
                            <li>Rs.60</li>
                        </ul>
                </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>No refund </p>                                
                </div>
            </div>
        </div>
    
    
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://2.bp.blogspot.com/-Q9lfQWDxdbI/XK1xXx0icpI/AAAAAAAAHYs/imzTLZRp-_QVtIA9vRvzm9hBtFlR-O23wCLcBGAs/s1600/IMG_0792.jpg">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Grape Milkshake</h3>
                            </div>  
                        </div>
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.5</span>
                                    </li>
                                    <li>•</li>
                                    <li>20 Mins</li>
						<li>food id:31</li>
                                    <li>•</li>
                                    <li>Rs.60</li>
                                </ul>
                            </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No refund  </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://asmallbite.com/wp-content/uploads/2019/05/Grilled-Paneer-Sandwich.jpg">
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Paneer Sandwich</h3>
                        </div>  
                    </div>
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.1</span>
                            </li>
                            <li>•</li>
                            <li>30 Mins</li>
					<li>food id:32</li>
                            <li>•</li>
                            <li>Rs.45</li>
                        </ul>
                    </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>Get renfund within 5 min from order  </p>                                
                </div>
            </div>
        </div>
       </div>  

                <!--Restaurant Block 3 -->
                <div class="listing-grid">
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://www.pepperbowl.com/wp-content/uploads/2019/09/how-to-make-rose-milk-syrup.jpg" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Rose Milk</h3>
                            </div>
                            </div>
                            <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>5.0</span>
                                        </li>
                                        <li>•</li>
                                        <li>15 Mins</li>
							<li>food id:33</li>
                                        <li>•</li>
                                        <li>Rs.35</li>
                                    </ul>
                            </div>
                            <div class="lower-text">
                                <div class="SmallText">             
			<p>No refund </p>                      
                            </div>
                        </div>
                    </div>
        
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://www.indianhealthyrecipes.com/wp-content/uploads/2021/06/strawberry-milkshake-recipe.jpg" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Strawberry Milkshake</h3>
                            </div>
                        </div>  
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star  avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.5</span>
                                </li>
                                <li>•</li>
                                <li>instant</li>
					<li>food id:34</li>
                                <li>•</li>
                                <li>Rs.50 For a Piece</li>
                            </ul>
                    </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund </p>                                
                    </div>
                </div>
            </div>
        
        
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://tamil.boldsky.com/img/2017/12/sugarcane-juice-during-pregnancy-12-1513078126.jpg">
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Karumbu juice</h3>
                                </div>  
                            </div>
                                <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>4.3</span>
                                        </li>
                                        <li>•</li>
                                        <li>10 Mins</li>
							<li>food id:35</li>
                                        <li>•</li>
                                        <li>Rs.10</li>
                                    </ul>
                                </div>
                            <div class="lower-text">
                                <div class="SmallText">
		<p>No Refund</p>
		</div>
                        </div>
                    </div>
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://blessmyfoodbypayal.com/wp-content/uploads/2020/09/IMG_20200905_183928-01_20200908220919421.jpg">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Corn</h3>
                            </div>  
                        </div>
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.9</span>
                                </li>
                                <li>•</li>
                                <li>Instant</li>
						<li>food id:36</li>
                                <li>•</li>
                                <li>Rs.15 </li>

                            </ul>
                        </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund </p>                                
                    </div>
                </div>
            </div>
           </div>
 <center><a href="order.php">Order</a>
        </form>