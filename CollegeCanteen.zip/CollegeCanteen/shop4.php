<html>
    <head>
        <link rel = "icon" href = "https://i.pinimg.com/originals/a9/c5/2e/a9c52e28c162e8fb6194705288f3e19e.jpg" type = "image/m-icon">
        <title>Foodie-Online  Ordering</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">       
        <link href="StyleSheet.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Charmonman|Lobster|Pacifico|Poppins|Raleway|Ubuntu" rel="stylesheet">        
    </head>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script> 
 <form action="order.php" method="POST"> 
<h1><center>FRESH JUICE DETAILS</center></h1>   
 <!--Restaurant Block 1-->
                    <div class="listing-grid">
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://tiimg.tistatic.com/fp/1/007/462/best-price-natural-and-fresh-apple-juice-for-daily-consumption-006.jpg" >
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Apple Juice</h3>
                                    <div class="info">
                                    </div>
                                </div>
                                </div>
                                <div class="info-rating">
                                        <ul>
                                            <li class="Rating-Star">
                                                <span><i class="fas fa-star"></i></span>
                                                <span>4.0</span>
                                            </li>
                                            <li>•</li>
                                            <li>5 MIN</li>
							 <li>Food id:37</li>
                                            <li>•</li>
                                            <li>Rs.30</li>
                                        </ul>
                                </div>
                                <div class="lower-text">
                                    <div class="SmallText">
                                    <p>No Refund</p>                                
                                </div>
                            </div>
                        </div>
            
            
            
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://thumbs.dreamstime.com/z/orange-juice-17172736.jpg" >
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Orange Juice</h3>
                                    <div class="info">                              
                                    </div>
                                </div>
                            </div>  
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star "></i></span>
                                        <span>4.9</span>
                                    </li>
                                    <li>•</li>
                                    <li>10 MIN</li>
						 <li>Food id:38</li>
                                    <li>•</li>
                                    <li>Rs.40</li>
                                </ul>
                        </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No Refund </p>                                
                        </div>
                    </div>
                </div>
                            <div class="listing-grid-elements">
                                <div class="image1">
                                   <img src="https://media.istockphoto.com/photos/watermelon-smoothie-picture-id1270069402?b=1&k=20&m=1270069402&s=170667a&w=0&h=6ejn4ns-pveGsWHg6exvyZwIGFRa3INNj5hVZZmXUyY=" >
         </div>
                                <div class="text">
                                    <div class="text-title">
                                        <h3>Watermelon Juice</h3>
                                    </div>  
                                </div>
                                    <div class="info-rating">
                                        <ul>
                                            <li class="Rating-Star">
                                                <span><i class="fas fa-star"></i></span>
                                                <span>4.5</span>
                                            </li>
                                            <li>•</li>
                                            <li>15 MIN</li>
							 <li>Food id:39</li>
                                            <li>•</li>
                                            <li>Rs.40</li>
                                        </ul>
                                    </div>
                                <div class="lower-text">
                                    <div class="SmallText">
                                    <p>No Refund </p>                                
                                </div>
                            </div>
                        </div>
                        
            
                            
            
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://4.imimg.com/data4/HR/VP/MY-30165244/lemon-juice-500x500.jpg">
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Lemon Juice</h3>
                                </div>  
                            </div>
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.2</span>
                                    </li>
                                    <li>•</li>
                                    <li>5 MINS</li>
						 <li>Food id:40</li>
                                    <li>•</li>
                                    <li>Rs.30</li>
                                </ul>
                            </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No Refund </p>                                
                        </div>
                    </div>
                </div>
               </div>  

            <!--Restaurant Block 2-->

            <div class="listing-grid">
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://5.imimg.com/data5/DT/PV/MY-28707171/magic-musk-melon-juice-500x500.png" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Muskmelon Juice</h3>
                        </div>
                        </div>
                        <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.4</span>
                                    </li>
                                    <li>•</li>
                                    <li>10 Mins</li>
						 <li>Food id:41</li>
                                    <li>•</li>
                                    <li>Rs.45</li>
                                </ul>
                        </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No Refund </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://healthynibblesandbits.com/wp-content/uploads/2016/11/How-to-Cut-a-Pomegranate-FF.jpg" >
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Pomegranate Juice</h3>
                        </div>
                    </div>  
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.5</span>
                            </li>
                            <li>•</li>
                            <li>15 Mins</li>
					 <li>Food id:42</li>
                            <li>•</li>
                            <li>Rs.40</li>
                        </ul>
                </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>No Refund   </p>                                
                </div>
            </div>
        </div>
    
    
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://image.shutterstock.com/image-photo/fresh-grape-juice-two-glasses-260nw-1505648246.jpg">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Grape Juice</h3>
                            </div>  
                        </div>
                            <div class="info-rating">
                                <ul>
                                    <li class="Rating-Star">
                                        <span><i class="fas fa-star"></i></span>
                                        <span>4.6</span>
                                    </li>
                                    <li>•</li>
                                    <li>5 Mins</li>
						 <li>Food id:43</li>
                                    <li>•</li>
                                    <li>Rs.30</li>
                                </ul>
                            </div>
                        <div class="lower-text">
                            <div class="SmallText">
                            <p>No Refund  </p>                                
                        </div>
                    </div>
                </div>
    
    
    
                    
    
                <div class="listing-grid-elements">
                    <div class="image1">
                        <img src="https://ankurpavbhaji.com/wp-content/uploads/2021/03/Pineapple-juice.jpg">
                    </div>
                    <div class="text">
                        <div class="text-title">
                            <h3>Pineapple Juice</h3>
                        </div>  
                    </div>
                    <div class="info-rating">
                        <ul>
                            <li class="Rating-Star">
                                <span><i class="fas fa-star"></i></span>
                                <span>4.1</span>
                            </li>
                            <li>•</li>
                            <li>15 Mins</li>
					 <li>Food id:44</li>
                            <li>•</li>
                            <li>Rs.50</li>
                        </ul>
                    </div>
                <div class="lower-text">
                    <div class="SmallText">
                    <p>No Refund  </p>                                
                </div>
            </div>
        </div>
       </div>  

                <!--Restaurant Block 3 -->
                <div class="listing-grid">
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://www.sailusfood.com/wp-content/uploads/2014/06/rose-milk-recipe.jpg" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Rose Milk</h3>
                            </div>
                            </div>
                            <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>4.9</span>
                                        </li>
                                        <li>•</li>
                                        <li>10 MINS</li>
							 <li>Food id:45</li>
                                        <li>•</li>
                                        <li>Rs.40</li>
                                    </ul>
                            </div>
                            <div class="lower-text">
                                <div class="SmallText">             
			<p>No refund </p>                      
                            </div>
                        </div>
                    </div>
        
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://static.wixstatic.com/media/f460ff_04ac79c8ce4046e598c32dc1b564a24f~mv2.jpg/v1/fill/w_720,h_810,al_c,q_85/f460ff_04ac79c8ce4046e598c32dc1b564a24f~mv2.jpg" >
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Sathukudi Juice</h3>
                            </div>
                        </div>  
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star  avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.5</span>
                                </li>
                                <li>•</li>
                                <li>10 MINS</li>
						 <li>Food id:46</li>
                                <li>•</li>
                                <li>Rs.50</li>
                            </ul>
                    </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No refund </p>                                
                    </div>
                </div>
            </div>
        
        
                        <div class="listing-grid-elements">
                            <div class="image1">
                                <img src="https://www.24mantra.com/wp-content/uploads/2020/04/5-simple-ways-to-enjoy-mangoes-this-summer-mango-juice-recipe.jpg">
                            </div>
                            <div class="text">
                                <div class="text-title">
                                    <h3>Mango Juice</h3>
                                </div>  
                            </div>
                                <div class="info-rating">
                                    <ul>
                                        <li class="Rating-Star">
                                            <span><i class="fas fa-star"></i></span>
                                            <span>4.7</span>
                                        </li>
                                        <li>•</li>
                                        <li>10 MINS Mins</li>
							 <li>Food id:47</li>
                                        <li>•</li>
                                        <li>Rs.40</li>
                                    </ul>
                                </div>
                            <div class="lower-text">
                                <div class="SmallText">
		<p>No Refund</p>
		</div>
                        </div>
                    </div>
        
        
                    <div class="listing-grid-elements">
                        <div class="image1">
                            <img src="https://img.freepik.com/free-photo/glass-papaya-juice-put-white-marble-floor_1150-28077.jpg?w=2000">
                        </div>
                        <div class="text">
                            <div class="text-title">
                                <h3>Papaya Juice</h3>
                            </div>  
                        </div>
                        <div class="info-rating">
                            <ul>
                                <li class="Rating-Star avg">
                                    <span><i class="fas fa-star"></i></span>
                                    <span>3.0</span>
                                </li>
                                <li>•</li>
                                <li>10 Mins</li>
					 <li>Food id:48</li>
                                <li>•</li>
                                <li>Rs.35</li>
                            </ul>
                        </div>
                    <div class="lower-text">
                        <div class="SmallText">
                        <p>No Refund</p>                                
                    </div>
                </div>
            </div>
           </div>
 <center><a href="order.php">Order</a>
        </form>