<!-- HTML code with embedded PHP code -->
<style>
	body {
		background-color: #fefbd8;
	}
	h3 {
		background-color: #333;
		color: white;
	}
</style>
<br>
<br>
<br>
<center>
<h3>CHOOSE THE CANTEEN YOU WISH TO ORDER</h3>

<br>
<a href="shop1.php">HOTEL MAYURA</a>
<br>

<br>
<a href="shop2.php">CAFE</a>
<br>

<br>
<a href="shop3.php">BEST CANTEEN</a>
<br>
<br>
<a href="shop4.php">FRESH JUICE</a>
<br>
</center>
